import type { QuizMode } from './MapQuiz';

type Props = {
  modes: QuizMode[];
  activeModeId: string;
  questionCount: string;
  onModeChange: (modeId: string) => void;
  onQuestionCountChange: (value: string) => void;
};

export default function ModeSelector({
  modes,
  activeModeId,
  questionCount,
  onModeChange,
  onQuestionCountChange,
}: Props) {
  return (
    <section className="mode-panel" aria-label="モード選択">
      <div className="mode-scroll">
        {modes.map((mode) => (
          <button
            className={`mode-button ${mode.id === activeModeId ? 'is-active' : ''}`}
            key={mode.id}
            type="button"
            onClick={() => onModeChange(mode.id)}
          >
            {mode.label}
          </button>
        ))}
      </div>
      <label className="count-select">
        <span>出題数</span>
        <select value={questionCount} onChange={(event) => onQuestionCountChange(event.target.value)}>
          <option value="10">10問</option>
          <option value="20">20問</option>
          <option value="50">50問</option>
          <option value="all">全問</option>
        </select>
      </label>
    </section>
  );
}
