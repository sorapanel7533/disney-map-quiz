export type Rank =
  | 'パークマスター'
  | 'かなり詳しい'
  | '普通に詳しい'
  | 'まだ伸びる'
  | '初心者';

export function getRank(percentage: number): Rank {
  if (percentage >= 95) return 'パークマスター';
  if (percentage >= 80) return 'かなり詳しい';
  if (percentage >= 60) return '普通に詳しい';
  if (percentage >= 40) return 'まだ伸びる';
  return '初心者';
}

export function scoreAnswers(spotIds: string[], answers: Record<string, string>) {
  const correct = spotIds.filter((id) => answers[id] === id).length;
  const total = spotIds.length;
  const percentage = total === 0 ? 0 : Math.round((correct / total) * 100);

  return {
    correct,
    total,
    percentage,
    rank: getRank(percentage),
  };
}

export function createShareText(modeLabel: string, correct: number, total: number, percentage: number, rank: Rank) {
  return [
    '東京ディズニーリゾート マップクイズ',
    `モード：${modeLabel}`,
    `結果：${correct} / ${total}`,
    `正答率：${percentage}%`,
    `ランク：${rank}`,
  ].join('\n');
}
