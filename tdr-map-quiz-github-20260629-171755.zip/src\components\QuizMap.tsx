import { useMemo, useRef, useState } from 'react';
import type { PointerEvent, WheelEvent } from 'react';
import type { Park, Spot } from '../data/spots';

type Props = {
  spots: Spot[];
  selectedSpotId: string | null;
  answers: Record<string, string>;
  graded: boolean;
  activePark: Park | 'mixed';
  onSelectSpot: (spotId: string) => void;
};

const areaShapes = {
  land: [
    { name: 'ワールドバザール', x: 38, y: 72, w: 24, h: 18, color: '#f7e3b3' },
    { name: 'アドベンチャーランド', x: 18, y: 62, w: 27, h: 23, color: '#cdebc4' },
    { name: 'ウエスタンランド', x: 18, y: 35, w: 27, h: 26, color: '#ead3a1' },
    { name: 'クリッターカントリー', x: 13, y: 52, w: 18, h: 20, color: '#d5e6b3' },
    { name: 'ファンタジーランド', x: 43, y: 30, w: 24, h: 28, color: '#f5d4e4' },
    { name: 'トゥーンタウン', x: 63, y: 16, w: 24, h: 19, color: '#d9e8ff' },
    { name: 'トゥモローランド', x: 66, y: 35, w: 23, h: 25, color: '#d4f0f4' },
  ],
  sea: [
    { name: 'メディテレーニアンハーバー', x: 30, y: 63, w: 28, h: 24, color: '#d9ecff' },
    { name: 'アメリカンウォーターフロント', x: 13, y: 38, w: 29, h: 25, color: '#f2d7c7' },
    { name: 'ポートディスカバリー', x: 43, y: 25, w: 22, h: 21, color: '#cbe8ee' },
    { name: 'ロストリバーデルタ', x: 61, y: 38, w: 25, h: 24, color: '#cfe5bc' },
    { name: 'アラビアンコースト', x: 62, y: 62, w: 25, h: 23, color: '#f4d9a1' },
    { name: 'マーメイドラグーン', x: 50, y: 70, w: 19, h: 20, color: '#d6d1f4' },
    { name: 'ミステリアスアイランド', x: 43, y: 49, w: 21, h: 20, color: '#d7d4cc' },
    { name: 'ファンタジースプリングス', x: 68, y: 12, w: 25, h: 22, color: '#e5d7fb' },
  ],
};

export default function QuizMap({ spots, selectedSpotId, answers, graded, activePark, onSelectSpot }: Props) {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const lastPinchDistance = useRef(0);
  const [view, setView] = useState({ scale: 1, x: 0, y: 0 });
  const parkForMap = useMemo(() => (activePark === 'sea' ? 'sea' : 'land'), [activePark]);
  const shapes =
    activePark === 'mixed'
      ? [
          ...areaShapes.land.map((shape) => ({
            ...shape,
            x: shape.x * 0.48 + 1,
            y: shape.y * 0.9 + 5,
            w: shape.w * 0.48,
            h: shape.h * 0.9,
          })),
          ...areaShapes.sea.map((shape) => ({
            ...shape,
            x: shape.x * 0.45 + 53,
            y: shape.y * 0.9 + 5,
            w: shape.w * 0.45,
            h: shape.h * 0.9,
          })),
        ]
      : areaShapes[parkForMap];

  function getDisplayPosition(spot: Spot) {
    if (activePark !== 'mixed') return { x: spot.x, y: spot.y };
    if (spot.park === 'land') return { x: spot.x * 0.48 + 1, y: spot.y * 0.9 + 5 };
    return { x: spot.x * 0.45 + 53, y: spot.y * 0.9 + 5 };
  }

  function updatePan(dx: number, dy: number) {
    setView((current) => ({ ...current, x: current.x + dx, y: current.y + dy }));
  }

  function updateScale(delta: number) {
    setView((current) => ({
      ...current,
      scale: Math.min(2.8, Math.max(0.85, current.scale + delta)),
    }));
  }

  function handlePointerDown(event: PointerEvent<HTMLDivElement>) {
    mapRef.current?.setPointerCapture(event.pointerId);
    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
  }

  function handlePointerMove(event: PointerEvent<HTMLDivElement>) {
    const previous = pointers.current.get(event.pointerId);
    if (!previous) return;

    pointers.current.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const activePointers = [...pointers.current.values()];

    if (activePointers.length === 1) {
      updatePan(event.clientX - previous.x, event.clientY - previous.y);
    }

    if (activePointers.length >= 2) {
      const [first, second] = activePointers;
      const distance = Math.hypot(first.x - second.x, first.y - second.y);
      if (lastPinchDistance.current > 0) {
        updateScale((distance - lastPinchDistance.current) / 220);
      }
      lastPinchDistance.current = distance;
    }
  }

  function handlePointerUp(event: PointerEvent<HTMLDivElement>) {
    pointers.current.delete(event.pointerId);
    if (pointers.current.size < 2) lastPinchDistance.current = 0;
  }

  function handleWheel(event: WheelEvent<HTMLDivElement>) {
    event.preventDefault();
    updateScale(event.deltaY > 0 ? -0.08 : 0.08);
  }

  function getPinState(spot: Spot) {
    if (!answers[spot.id]) return 'unanswered';
    if (!graded) return 'answered';
    return answers[spot.id] === spot.id ? 'correct' : 'wrong';
  }

  return (
    <section className="map-panel">
      <div
        className="map-viewport"
        ref={mapRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onWheel={handleWheel}
      >
        <div
          className={`quiz-map ${activePark === 'mixed' ? 'is-mixed' : ''}`}
          style={{ transform: `translate(${view.x}px, ${view.y}px) scale(${view.scale})` }}
        >
          {shapes.map((shape, index) => (
            <div
              className="area-shape"
              key={`${shape.name}-${index}`}
              style={{
                left: `${shape.x}%`,
                top: `${shape.y}%`,
                width: `${shape.w}%`,
                height: `${shape.h}%`,
                background: shape.color,
              }}
            >
              <span>{shape.name}</span>
            </div>
          ))}
          <div className="water-ring" />
          {spots.map((spot, index) => {
            const position = getDisplayPosition(spot);
            return (
              <button
                className={`map-pin ${getPinState(spot)} ${selectedSpotId === spot.id ? 'is-selected' : ''}`}
                key={spot.id}
                type="button"
                style={{ left: `${position.x}%`, top: `${position.y}%` }}
                onClick={(event) => {
                  event.stopPropagation();
                  onSelectSpot(spot.id);
                }}
                aria-label={`${index + 1}番 ${spot.area}`}
              >
                {index + 1}
              </button>
            );
          })}
        </div>
      </div>
      <div className="map-tools">
        <button type="button" onClick={() => updateScale(0.15)}>+</button>
        <button type="button" onClick={() => updateScale(-0.15)}>-</button>
        <button type="button" onClick={() => setView({ scale: 1, x: 0, y: 0 })}>戻す</button>
      </div>
    </section>
  );
}
