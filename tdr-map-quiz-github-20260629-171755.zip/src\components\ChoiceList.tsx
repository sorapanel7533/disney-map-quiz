import { useState } from 'react';
import { Search } from 'lucide-react';
import type { Spot } from '../data/spots';

type Props = {
  spots: Spot[];
  selectedSpotId: string | null;
  answers: Record<string, string>;
  onChoose: (choiceId: string) => void;
};

const categoryLabel = {
  attraction: 'アトラクション',
  restaurant: 'レストラン',
  shop: 'ショップ',
};

export default function ChoiceList({ spots, selectedSpotId, answers, onChoose }: Props) {
  const selectedAnswer = selectedSpotId ? answers[selectedSpotId] : undefined;
  const [query, setQuery] = useState('');
  const normalizedQuery = query.trim().toLowerCase();
  const filteredSpots = spots.filter((spot) => {
    const text = `${spot.name} ${spot.area} ${categoryLabel[spot.category]}`.toLowerCase();
    return text.includes(normalizedQuery);
  });

  return (
    <section className="choices-panel">
      <div className="search-box">
        <Search aria-hidden="true" size={18} />
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="施設名・エリアで検索"
          type="search"
        />
      </div>
      <div className="choice-list" aria-label="選択肢一覧">
        {filteredSpots.map((spot) => (
          <button
            className={`choice-button ${selectedAnswer === spot.id ? 'is-selected' : ''}`}
            disabled={!selectedSpotId}
            key={spot.id}
            type="button"
            onClick={() => onChoose(spot.id)}
          >
            <span>{spot.name}</span>
            <small>{spot.area}・{categoryLabel[spot.category]}</small>
          </button>
        ))}
      </div>
    </section>
  );
}
