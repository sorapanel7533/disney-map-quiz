import MapQuiz from './components/MapQuiz';

export default function App() {
  return (
    <div className="app-shell">
      <header className="app-header">
        <div>
          <p className="eyebrow">非公式ファンメイド</p>
          <h1>東京ディズニーリゾート マップクイズ</h1>
        </div>
      </header>
      <MapQuiz />
      <footer className="app-footer">
        このアプリは個人用の非公式ファンアプリです。東京ディズニーリゾート公式とは関係ありません。公式ロゴ、公式地図、キャラクター画像は使用していません。
      </footer>
    </div>
  );
}
