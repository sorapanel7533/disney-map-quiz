import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, RotateCcw } from 'lucide-react';
import ChoiceList from './ChoiceList';
import ModeSelector from './ModeSelector';
import QuizMap from './QuizMap';
import ResultModal from './ResultModal';
import { spots, type Park, type Spot } from '../data/spots';
import { createShareText, scoreAnswers } from '../utils/scoring';

export type QuizMode = {
  id: string;
  label: string;
  park: Park | 'mixed';
  filter: (spot: Spot) => boolean;
};

const modes: QuizMode[] = [
  {
    id: 'land_attractions',
    label: 'ランド：アトラクションのみ',
    park: 'land',
    filter: (spot) => spot.park === 'land' && spot.category === 'attraction',
  },
  {
    id: 'land_all',
    label: 'ランド：全施設',
    park: 'land',
    filter: (spot) => spot.park === 'land',
  },
  {
    id: 'sea_attractions',
    label: 'シー：アトラクションのみ',
    park: 'sea',
    filter: (spot) => spot.park === 'sea' && spot.category === 'attraction',
  },
  {
    id: 'sea_all',
    label: 'シー：全施設',
    park: 'sea',
    filter: (spot) => spot.park === 'sea',
  },
  {
    id: 'mixed_all',
    label: '両パークすべて',
    park: 'mixed',
    filter: () => true,
  },
  {
    id: 'fantasy_springs',
    label: 'ファンタジースプリングスのみ',
    park: 'sea',
    filter: (spot) => spot.area === 'ファンタジースプリングス',
  },
  {
    id: 'hard',
    label: '難問モード',
    park: 'mixed',
    filter: (spot) => spot.difficulty >= 2 && spot.category !== 'attraction',
  },
];

const storageKey = 'tdr-map-quiz-state-v1';

type SavedState = {
  modeId: string;
  questionCount: string;
  questionIds: string[];
  answers: Record<string, string>;
};

export default function MapQuiz() {
  const [modeId, setModeId] = useState(modes[0].id);
  const [questionCount, setQuestionCount] = useState('10');
  const [questionIds, setQuestionIds] = useState<string[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [selectedSpotId, setSelectedSpotId] = useState<string | null>(null);
  const [graded, setGraded] = useState(false);
  const [showResult, setShowResult] = useState(false);

  const activeMode = modes.find((mode) => mode.id === modeId) ?? modes[0];
  const quizSpots = useMemo(
    () => questionIds.map((id) => spots.find((spot) => spot.id === id)).filter(Boolean) as Spot[],
    [questionIds],
  );
  const answeredCount = quizSpots.filter((spot) => answers[spot.id]).length;
  const result = scoreAnswers(questionIds, answers);
  const shareText = createShareText(activeMode.label, result.correct, result.total, result.percentage, result.rank);

  useEffect(() => {
    const saved = localStorage.getItem(storageKey);
    if (!saved) {
      startNewQuiz(modes[0].id, '10');
      return;
    }

    try {
      const parsed = JSON.parse(saved) as SavedState;
      setModeId(parsed.modeId);
      setQuestionCount(parsed.questionCount);
      setQuestionIds(parsed.questionIds);
      setAnswers(parsed.answers);
    } catch {
      startNewQuiz(modes[0].id, '10');
    }
  }, []);

  useEffect(() => {
    if (questionIds.length === 0) return;
    const saved: SavedState = { modeId, questionCount, questionIds, answers };
    localStorage.setItem(storageKey, JSON.stringify(saved));
  }, [answers, modeId, questionCount, questionIds]);

  function startNewQuiz(nextModeId = modeId, nextQuestionCount = questionCount) {
    const mode = modes.find((item) => item.id === nextModeId) ?? modes[0];
    const pool = spots.filter(mode.filter);
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const limit = nextQuestionCount === 'all' ? shuffled.length : Math.min(Number(nextQuestionCount), shuffled.length);
    setModeId(nextModeId);
    setQuestionCount(nextQuestionCount);
    setQuestionIds(shuffled.slice(0, limit).map((spot) => spot.id));
    setAnswers({});
    setSelectedSpotId(null);
    setGraded(false);
    setShowResult(false);
  }

  function handleModeChange(nextModeId: string) {
    startNewQuiz(nextModeId, questionCount);
  }

  function handleQuestionCountChange(value: string) {
    startNewQuiz(modeId, value);
  }

  function handleChoose(choiceId: string) {
    if (!selectedSpotId) return;
    setAnswers((current) => ({ ...current, [selectedSpotId]: choiceId }));
  }

  function handleGrade() {
    setGraded(true);
    setShowResult(true);
  }

  function handleReset() {
    localStorage.removeItem(storageKey);
    startNewQuiz(modeId, questionCount);
  }

  return (
    <main className="quiz-layout">
      <div className="top-row">
        <ModeSelector
          modes={modes}
          activeModeId={modeId}
          questionCount={questionCount}
          onModeChange={handleModeChange}
          onQuestionCountChange={handleQuestionCountChange}
        />
        <div className="answer-counter">
          <span>回答数</span>
          <strong>{answeredCount} / {quizSpots.length}</strong>
        </div>
      </div>

      <p className="guide-text">地図または番号を選んでから、下の選択肢をクリックしてください</p>

      <QuizMap
        spots={quizSpots}
        selectedSpotId={selectedSpotId}
        answers={answers}
        graded={graded}
        activePark={activeMode.park}
        onSelectSpot={setSelectedSpotId}
      />

      <div className="selected-strip">
        {selectedSpotId ? (
          <span>選択中：{quizSpots.find((spot) => spot.id === selectedSpotId)?.area} のピン</span>
        ) : (
          <span>未選択</span>
        )}
        <div className="action-buttons">
          <button className="secondary-button" type="button" onClick={handleReset}>
            <RotateCcw size={17} />
            リセット
          </button>
          <button className="primary-button" type="button" onClick={handleGrade}>
            <CheckCircle2 size={18} />
            採点
          </button>
        </div>
      </div>

      <ChoiceList spots={quizSpots} selectedSpotId={selectedSpotId} answers={answers} onChoose={handleChoose} />

      {showResult && (
        <ResultModal
          correct={result.correct}
          total={result.total}
          percentage={result.percentage}
          rank={result.rank}
          shareText={shareText}
          onRetry={() => startNewQuiz(modeId, questionCount)}
          onClose={() => setShowResult(false)}
        />
      )}
    </main>
  );
}
