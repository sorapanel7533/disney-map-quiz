import { Copy, RotateCcw, X } from 'lucide-react';
import type { Rank } from '../utils/scoring';

type Props = {
  correct: number;
  total: number;
  percentage: number;
  rank: Rank;
  shareText: string;
  onRetry: () => void;
  onClose: () => void;
};

export default function ResultModal({ correct, total, percentage, rank, shareText, onRetry, onClose }: Props) {
  async function handleCopy() {
    await navigator.clipboard.writeText(shareText);
  }

  return (
    <div className="modal-backdrop" role="presentation">
      <section className="result-modal" role="dialog" aria-modal="true" aria-label="採点結果">
        <button className="icon-button modal-close" type="button" onClick={onClose} aria-label="閉じる">
          <X size={18} />
        </button>
        <p className="eyebrow">採点結果</p>
        <h2>{rank}</h2>
        <div className="score-grid">
          <div>
            <span>正解数</span>
            <strong>{correct} / {total}</strong>
          </div>
          <div>
            <span>正答率</span>
            <strong>{percentage}%</strong>
          </div>
        </div>
        <textarea className="share-text" value={shareText} readOnly aria-label="コピー用テキスト" />
        <div className="modal-actions">
          <button className="primary-button" type="button" onClick={handleCopy}>
            <Copy size={18} />
            コピー
          </button>
          <button className="secondary-button" type="button" onClick={onRetry}>
            <RotateCcw size={18} />
            再挑戦
          </button>
          <button className="secondary-button" type="button" onClick={onClose}>
            閉じる
          </button>
        </div>
      </section>
    </div>
  );
}
